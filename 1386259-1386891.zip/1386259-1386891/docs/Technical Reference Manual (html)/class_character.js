var class_character =
[
    [ "~Character", "class_character.html#af3ec409c562122c4464e8a9d3be5f6d2", null ],
    [ "getPosition", "class_character.html#a28e3e8fc20302a580e6c67332f417b86", null ],
    [ "respawn", "class_character.html#adf2245e81f4bf26e9f2bff8daaeee85d", null ],
    [ "unpauseCharacter", "class_character.html#a62abf773ccedc73f091038afed7f0e69", null ]
];