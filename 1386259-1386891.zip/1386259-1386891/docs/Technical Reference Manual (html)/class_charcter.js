var class_charcter =
[
    [ "getPosition", "class_charcter.html#a9f565b40454d4d8153ba0d1a501d2c40", null ],
    [ "respawn", "class_charcter.html#ab6bd1f061c4c40a3f8c4abad3c5a4c36", null ],
    [ "unpauseCharacter", "class_charcter.html#a10e7a72c7d39b71709163a156c267711", null ],
    [ "update", "class_charcter.html#adf10feb7a6c49a437b8dba508cbb50e3", null ]
];