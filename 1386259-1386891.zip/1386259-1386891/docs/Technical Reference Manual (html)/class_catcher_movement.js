var class_catcher_movement =
[
    [ "CatcherMovement", "class_catcher_movement.html#ac1b88379b84c9ff821bda422369fedf5", null ],
    [ "getDirection", "class_catcher_movement.html#ac865c7439cea6618501cfa2b7c63ae9b", null ],
    [ "randomMovement", "class_catcher_movement.html#aa546388a07a18ca6050f235a1e08928a", null ]
];