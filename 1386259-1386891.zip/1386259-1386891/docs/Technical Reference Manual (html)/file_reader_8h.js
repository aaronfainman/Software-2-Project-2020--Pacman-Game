var file_reader_8h =
[
    [ "fileCantBeOpened", "classfile_cant_be_opened.html", null ],
    [ "FileReader", "class_file_reader.html", "class_file_reader" ],
    [ "vector2D", "file_reader_8h.html#adc3e3c1b5fa1330260113c8b5ec52dab", null ]
];