var searchData=
[
  ['userinput_384',['UserInput',['../class_screen.html#abea689aa736c9c26de392af244f1bff5',1,'Screen']]]
];
