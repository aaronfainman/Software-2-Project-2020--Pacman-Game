var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwxy~",
  1: "cdfgmpsu",
  2: "cdfgmpsu",
  3: "acdfghimnoprsuxy~",
  4: "cdmntw",
  5: "cdtv",
  6: "cdmp",
  7: "abcdeklnprsuw",
  8: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends"
};

