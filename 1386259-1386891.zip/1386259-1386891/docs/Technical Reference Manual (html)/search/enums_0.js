var searchData=
[
  ['charactertype_347',['characterType',['../_common_constants_8h.html#a7d75b50b74629008f75188a085887738',1,'CommonConstants.h']]],
  ['collisiontype_348',['collisionType',['../_common_constants_8h.html#aae32cab8ad87bad8925001b03edfdc5f',1,'CommonConstants.h']]]
];
