var searchData=
[
  ['newdrawables_290',['newDrawables',['../class_screen.html#a2f9f240b8c9c6573711c5ab40ab03223',1,'Screen']]],
  ['nobonesleft_291',['noBonesLeft',['../class_maze.html#a113aabcb3bc1cfb1f7871e2d578e4a8b',1,'Maze']]]
];
