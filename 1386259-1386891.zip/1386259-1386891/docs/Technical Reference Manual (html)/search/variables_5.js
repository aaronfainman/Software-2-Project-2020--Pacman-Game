var searchData=
[
  ['window_5fsize_5fx_341',['WINDOW_SIZE_X',['../_common_constants_8h.html#a7375d1f6a4c59c6c19047a9521a1ecd5',1,'CommonConstants.h']]],
  ['window_5fsize_5fy_342',['WINDOW_SIZE_Y',['../_common_constants_8h.html#a560b5e8210be9ced3ba1882a36d52bd9',1,'CommonConstants.h']]]
];
