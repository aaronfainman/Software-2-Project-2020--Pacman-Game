var searchData=
[
  ['character_5fsize_5fx_334',['CHARACTER_SIZE_X',['../_common_constants_8h.html#a9ef380edf155fd30933767e7df57d47b',1,'CommonConstants.h']]],
  ['character_5fsize_5fy_335',['CHARACTER_SIZE_Y',['../_common_constants_8h.html#a2a93a8b51f1eba0a56341937e22cd695',1,'CommonConstants.h']]]
];
