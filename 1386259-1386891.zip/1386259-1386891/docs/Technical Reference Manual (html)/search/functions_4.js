var searchData=
[
  ['game_267',['Game',['../class_game.html#a0e6e5b005f2772672a046f5d2f16bf9e',1,'Game']]],
  ['gameactive_268',['GameActive',['../class_game_active.html#afb7bfeb1ede00fb78541455696f7646c',1,'GameActive']]],
  ['gameover_269',['GameOver',['../class_game_over.html#ae27bbba4b0429fe4fe42efbe0bc5bd07',1,'GameOver']]],
  ['gamepaused_270',['GamePaused',['../class_game_paused.html#a07190aba1c9fe1beb440856ea13c3f26',1,'GamePaused']]],
  ['gamestart_271',['GameStart',['../class_game_start.html#adc653c5c0fa9997d294746cabbd0573a',1,'GameStart']]],
  ['gamesteak_272',['GameSteak',['../class_game_steak.html#a81e205833043fcf09a5002ebe5117b24',1,'GameSteak']]],
  ['getcharacterstart_273',['getCharacterStart',['../class_maze.html#a64bec3e34e4fd71927aaafd39c71d2ac',1,'Maze']]],
  ['getcollidedcatcher_274',['getCollidedCatcher',['../class_collisions.html#a86d5cb975a02cf350b06ccba0a7283c0',1,'Collisions']]],
  ['getdirection_275',['getDirection',['../class_catcher_movement.html#ac865c7439cea6618501cfa2b7c63ae9b',1,'CatcherMovement']]],
  ['getposition_276',['getPosition',['../class_catcher.html#afac22d93e3d1cb8c77d9d6231576799c',1,'Catcher::getPosition()'],['../class_character.html#a28e3e8fc20302a580e6c67332f417b86',1,'Character::getPosition()'],['../class_dog.html#a7bf858d8caf7cb390f67144181cc81c4',1,'Dog::getPosition()']]],
  ['gridposition_277',['GridPosition',['../class_grid_position.html#a056fcd9d4b8d755e1e2b804c3d52de1c',1,'GridPosition::GridPosition()=default'],['../class_grid_position.html#a5952b497ef5a6bae14cdeaf99deaf71c',1,'GridPosition::GridPosition(int row, int col)'],['../class_grid_position.html#acfd4b5807b7a5431308d6dc6c4886c33',1,'GridPosition::GridPosition(const GridPosition &amp;pos)']]]
];
