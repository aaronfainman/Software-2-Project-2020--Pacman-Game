var class_collisions =
[
    [ "Collisions", "class_collisions.html#a48d8b5382d0e51fa6a288d6d6e8bcc24", null ],
    [ "checkCollisions", "class_collisions.html#afc32ae23c067a18839a650cd2030d47e", null ],
    [ "getCollidedCatcher", "class_collisions.html#a86d5cb975a02cf350b06ccba0a7283c0", null ]
];