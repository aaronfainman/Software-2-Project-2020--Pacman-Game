var class_game_active =
[
    [ "GameActive", "class_game_active.html#afb7bfeb1ede00fb78541455696f7646c", null ],
    [ "~GameActive", "class_game_active.html#a3ec9641c164f7f871f46fba5b8f6fa60", null ],
    [ "draw", "class_game_active.html#a8ad8cd339d7cfbe69b3b8fc184e387bb", null ],
    [ "handleCollisions", "class_game_active.html#a3c9a9f59b4f3b2f7f13b89e11ddd6329", null ],
    [ "handleInput", "class_game_active.html#ab3a72309aeac2d0bb4eb0db9b1c5bcea", null ],
    [ "updateCharacters", "class_game_active.html#ada586bba23fd621f6c8114253f55c3d4", null ]
];