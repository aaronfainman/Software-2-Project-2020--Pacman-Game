var class_dog =
[
    [ "Dog", "class_dog.html#aab3e1b82e4c1fb84800a658c023db92a", null ],
    [ "Dog", "class_dog.html#acc2a2cf940ee7ab35896a75dc50bd8e1", null ],
    [ "changeDirection", "class_dog.html#a1480577cfb9cfaee4ce96915dd6d22ee", null ],
    [ "getPosition", "class_dog.html#a7bf858d8caf7cb390f67144181cc81c4", null ],
    [ "representation", "class_dog.html#a5443fbe08cd05ee74433d9422316d12f", null ],
    [ "respawn", "class_dog.html#a87d6884ac67caacd6a00345126b431ca", null ],
    [ "unpauseCharacter", "class_dog.html#aa052c8982c2f2f0650bd1a8d30da78dd", null ],
    [ "update", "class_dog.html#a797c105284dfe86419cc13a4c155d8b2", null ]
];