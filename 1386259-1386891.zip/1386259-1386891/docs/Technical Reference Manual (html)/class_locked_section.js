var class_locked_section =
[
    [ "LockedSection", "class_locked_section.html#ac16f59809b05132b1e2a7959df1b8621", null ],
    [ "retrieveCoordinates", "class_locked_section.html#a93dd9d2af6beee79118968c4b6be649e", null ]
];