var class_game =
[
    [ "Game", "class_game.html#a0e6e5b005f2772672a046f5d2f16bf9e", null ],
    [ "isOver", "class_game.html#a97e0e36ce9b219ba8a312c194e1bbc0c", null ],
    [ "run", "class_game.html#a1ab78f5ed0d5ea879157357cf2fb2afa", null ]
];