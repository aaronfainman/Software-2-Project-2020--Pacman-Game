var class_score =
[
    [ "Score", "class_score.html#ad1eb1ed40d41228b2684d0bdb0a56cf9", null ],
    [ "currentScore", "class_score.html#a98c05af2a4717099d39015af515fed14", null ],
    [ "highScore", "class_score.html#adc8640e1abb2a327a176b3c7bab77c95", null ],
    [ "highScoreReached", "class_score.html#a7d54cd01c9ed0ce6fc111cf2a3b41b3c", null ],
    [ "updateScore", "class_score.html#ad885404f27340df522adc580f0786ff1", null ]
];