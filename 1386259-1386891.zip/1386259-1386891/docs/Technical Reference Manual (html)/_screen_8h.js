var _screen_8h =
[
    [ "Screen", "class_screen.html", "class_screen" ],
    [ "drawableVec", "_screen_8h.html#a0a047b9ad4308fdc56d51424f4ddc350", null ],
    [ "textVec", "_screen_8h.html#a2b3da81f9edc486afafce9e8bf6be303", null ]
];