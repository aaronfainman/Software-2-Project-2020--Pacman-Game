var class_drawable =
[
    [ "Drawable", "class_drawable.html#aac88608db6081da479c772c96636acb1", null ],
    [ "~Drawable", "class_drawable.html#abdc2e2d82c51c1703656a2dfba0feabd", null ],
    [ "representation", "class_drawable.html#a9deef82344cc3c4112773736e2351f77", null ]
];