var class_movement =
[
    [ "Movement", "class_movement.html#a2cd84671f159995263bedfe4c1ead152", null ],
    [ "changeDirection", "class_movement.html#ad17b1464df94311ae9eaf5872aebf273", null ],
    [ "currentDirection", "class_movement.html#a7489f37f880841ea3cfdccad7db93eab", null ],
    [ "possibleDirections", "class_movement.html#a3f1336676185ca599386d375a542df4f", null ],
    [ "restartMovement", "class_movement.html#a24f92e50ca4c17b13db49f8387983286", null ],
    [ "updatePosition", "class_movement.html#a9363d3047881ed1145b5293355c7c32d", null ]
];