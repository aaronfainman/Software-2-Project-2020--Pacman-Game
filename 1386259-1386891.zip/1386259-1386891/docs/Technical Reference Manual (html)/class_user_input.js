var class_user_input =
[
    [ "Pressed", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3bec", [
      [ "RIGHT", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3beca21507b40c80068eda19865706fdc2403", null ],
      [ "UP", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3becafbaedde498cdead4f2780217646e9ba1", null ],
      [ "DOWN", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3becac4e0e4e3118472beeb2ae75827450f1f", null ],
      [ "LEFT", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3beca684d325a7303f52e64011467ff5c5758", null ],
      [ "SPACE", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3beca6506ae39fdca9845e3a6de3865183e57", null ],
      [ "ENTER", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3beca331b3100a485d8cacff1d3df8e9b0c13", null ],
      [ "CLOSE", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3beca7286293c9125ac7d7bace94c190bc16d", null ],
      [ "NONE", "class_user_input.html#a580ac0e75b1d9d3c94f01277f03c3becab50339a10e1de285ac99d4c3990b8693", null ]
    ] ],
    [ "UserInput", "class_user_input.html#adb84e1ba556780cb1a1d461061418352", null ],
    [ "input", "class_user_input.html#a3736713998f01d49f2c0febd3de7350b", null ]
];