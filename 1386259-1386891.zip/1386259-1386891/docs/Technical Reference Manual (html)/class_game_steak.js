var class_game_steak =
[
    [ "GameSteak", "class_game_steak.html#a81e205833043fcf09a5002ebe5117b24", null ],
    [ "~GameSteak", "class_game_steak.html#a22c008c3a53bf8a2026298293da5f974", null ],
    [ "draw", "class_game_steak.html#ae357cf651b3035388b01e0542607a5d9", null ],
    [ "handleCollisions", "class_game_steak.html#abb48ca0246dc288bf12f13d731df825a", null ],
    [ "handleInput", "class_game_steak.html#a9d4668fbc1f52f172debd24c6dcad06f", null ],
    [ "updateCharacters", "class_game_steak.html#a332bdcc9f6efbcc2029f8e95c1413cdb", null ]
];