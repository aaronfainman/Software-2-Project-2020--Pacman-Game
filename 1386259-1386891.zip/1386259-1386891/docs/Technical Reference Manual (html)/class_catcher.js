var class_catcher =
[
    [ "movementMode", "class_catcher.html#a990cf776e352f38c7038480403d4c3e3", [
      [ "smart", "class_catcher.html#a990cf776e352f38c7038480403d4c3e3a8c319f28d81d1527a9428e9a5c2195f5", null ],
      [ "random", "class_catcher.html#a990cf776e352f38c7038480403d4c3e3a7ddf32e17a6ac5ce04a8ecbf782ca509", null ]
    ] ],
    [ "Catcher", "class_catcher.html#a7a1f0b67864156c17ea0def06085d2c4", null ],
    [ "getPosition", "class_catcher.html#afac22d93e3d1cb8c77d9d6231576799c", null ],
    [ "representation", "class_catcher.html#a72d7f1ccbb2ad441e7801463f019763e", null ],
    [ "respawn", "class_catcher.html#ae1ddc6f55510d7aa5c99aa02de8a6698", null ],
    [ "unpauseCharacter", "class_catcher.html#a96ef55f4bbcd1315a62e2401ad98f025", null ],
    [ "update", "class_catcher.html#a2888b5cd312de660f3aa6dde9d725d6f", null ]
];