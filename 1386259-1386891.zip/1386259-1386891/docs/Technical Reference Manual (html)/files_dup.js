var files_dup =
[
    [ "Catcher.cpp", "_catcher_8cpp.html", null ],
    [ "Catcher.h", "_catcher_8h.html", "_catcher_8h" ],
    [ "CatcherMovement.cpp", "_catcher_movement_8cpp.html", null ],
    [ "CatcherMovement.h", "_catcher_movement_8h.html", [
      [ "CatcherMovement", "class_catcher_movement.html", "class_catcher_movement" ]
    ] ],
    [ "Character.h", "_character_8h.html", [
      [ "Character", "class_character.html", "class_character" ]
    ] ],
    [ "Collisions.cpp", "_collisions_8cpp.html", null ],
    [ "Collisions.h", "_collisions_8h.html", [
      [ "Collisions", "class_collisions.html", "class_collisions" ]
    ] ],
    [ "CommonConstants.h", "_common_constants_8h.html", "_common_constants_8h" ],
    [ "Dog.cpp", "_dog_8cpp.html", null ],
    [ "Dog.h", "_dog_8h.html", "_dog_8h" ],
    [ "Drawable.h", "_drawable_8h.html", "_drawable_8h" ],
    [ "fileReader.cpp", "file_reader_8cpp.html", null ],
    [ "fileReader.h", "file_reader_8h.html", "file_reader_8h" ],
    [ "Game.cpp", "_game_8cpp.html", null ],
    [ "Game.h", "_game_8h.html", "_game_8h" ],
    [ "GameActive.cpp", "_game_active_8cpp.html", null ],
    [ "GameActive.h", "_game_active_8h.html", [
      [ "GameActive", "class_game_active.html", "class_game_active" ]
    ] ],
    [ "GameOver.cpp", "_game_over_8cpp.html", null ],
    [ "GameOver.h", "_game_over_8h.html", [
      [ "GameOver", "class_game_over.html", "class_game_over" ]
    ] ],
    [ "GamePaused.cpp", "_game_paused_8cpp.html", null ],
    [ "GamePaused.h", "_game_paused_8h.html", [
      [ "GamePaused", "class_game_paused.html", "class_game_paused" ]
    ] ],
    [ "GameStart.cpp", "_game_start_8cpp.html", null ],
    [ "GameStart.h", "_game_start_8h.html", [
      [ "GameStart", "class_game_start.html", "class_game_start" ]
    ] ],
    [ "GameState.h", "_game_state_8h.html", [
      [ "GameState", "class_game_state.html", "class_game_state" ]
    ] ],
    [ "GameSteak.cpp", "_game_steak_8cpp.html", null ],
    [ "GameSteak.h", "_game_steak_8h.html", [
      [ "GameSteak", "class_game_steak.html", "class_game_steak" ]
    ] ],
    [ "GridPosition.cpp", "_grid_position_8cpp.html", null ],
    [ "GridPosition.h", "_grid_position_8h.html", [
      [ "GridPosition", "class_grid_position.html", "class_grid_position" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "maze.cpp", "maze_8cpp.html", null ],
    [ "maze.h", "maze_8h.html", "maze_8h" ],
    [ "Movement.cpp", "_movement_8cpp.html", null ],
    [ "Movement.h", "_movement_8h.html", [
      [ "Movement", "class_movement.html", "class_movement" ]
    ] ],
    [ "Position.cpp", "_position_8cpp.html", null ],
    [ "Position.h", "_position_8h.html", [
      [ "Position", "class_position.html", "class_position" ]
    ] ],
    [ "Score.cpp", "_score_8cpp.html", null ],
    [ "Score.h", "_score_8h.html", [
      [ "Score", "class_score.html", "class_score" ]
    ] ],
    [ "Screen.cpp", "_screen_8cpp.html", null ],
    [ "Screen.h", "_screen_8h.html", "_screen_8h" ],
    [ "UserInput.cpp", "_user_input_8cpp.html", null ],
    [ "UserInput.h", "_user_input_8h.html", [
      [ "UserInput", "class_user_input.html", "class_user_input" ]
    ] ]
];